package com.example.midtermproject

data class Task(val name: String ="", var isCompleted: Boolean = false)