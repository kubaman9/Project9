Won Kim and Jakub Kielczewski
